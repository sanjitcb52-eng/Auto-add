const CACHE_NAME = 'nfc-attendance-v1';
const ASSETS = [
  '/scan.html',
  '/login.html',
  '/dashboard.html',
  '/register-card.html',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => response || fetch(event.request))
  );
});